<?php

echo '<a href="invoice.php">..</a>';

?>